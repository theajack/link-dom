// /*
//  * @Author: chenzhongsheng
//  * @Date: 2025-09-06 15:44:09
//  * @Description: Coding something
//  */
// import { dom } from 'link-dom';

// export function comp () {
//     const a = (() => {
//         const x = 1;
//         return () => console.log(x);
//     })();

//     const el = dom.div.class('app').append(
//         dom.span.text('').click(a)
//     );
//     return el;
// }