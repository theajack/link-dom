// /*
//  * @Author: chenzhongsheng
//  * @Date: 2025-09-06 14:58:43
//  * @Description: Coding something
//  */
// import { comp } from 'link-dom';
// import { useSSR } from 'link-dom-ssr';

// useSSR();

// const a = (() => {
//     const x = 1;
//     return () => console.log(x);
// })();

// const el = dom.div.class('app').append(
//     dom.span.text('').click(a)
// );

// console.log(el);
// debugger;