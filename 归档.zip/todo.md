<!--
 * @Author: chenzhongsheng
 * @Date: 2025-09-06 18:16:04
 * @Description: Coding something
-->

- [x] 自定义渲染
- [x] 单向数据流
- [] ssr 支持
- [] 路由支持